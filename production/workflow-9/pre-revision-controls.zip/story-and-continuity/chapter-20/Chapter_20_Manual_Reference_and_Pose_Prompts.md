# Chapter 20 — reference generation and posture lineage

Future execution only. Read production/Reference_Lineage_Workflow.md. GPT Image 2.6 Flare, quality medium, 2K, 4:3, one PNG. First accept turnaround, then neutral posture with soft attached shadow, then each expression from that one neutral image. No previous-expression chaining or reference bundles. Existing deliveries are unchanged.

| Page | Source states and lineage nodes |
| --- | --- |
| c20-s01-p01 | CH20_B01:ONE → A_CH20_B01_ONE |
| c20-s01-p02 | CH20_B01:ONE → A_CH20_B01_ONE; CH20_C01:ONE → V_CH20_C01_ONE |
| c20-s01-p03 | CH20_B01:ONE → A_CH20_B01_ONE; CH20_S01:ONE → V_CH20_S01_ONE |
| c20-s01-p04 | CH20_B01:ONE → A_CH20_B01_ONE; CH20_S01:ONE → V_CH20_S01_ONE |
| c20-s01-p05 | CH20_B01:ONE → A_CH20_B01_ONE; CH20_S01:ONE → V_CH20_S01_ONE |
| c20-s01-p06 | CH20_B01:ONE → A_CH20_B01_ONE; CH20_S01:ONE → V_CH20_S01_ONE |
| c20-s02-p01 | CH20_B01:ONE → A_CH20_B01_ONE; CH03_C02:ONE → V_CH03_C02_ONE; CH08_R03:L → V_CH08_R03_L |
| c20-s02-p02 | CH20_B01:ONE → A_CH20_B01_ONE; CH03_C02:ONE → V_CH03_C02_ONE |
| c20-s02-p03 | CH20_B01:ONE → A_CH20_B01_ONE; CH03_C02:ONE → V_CH03_C02_ONE |
| c20-s02-p04 | CH20_B01:ONE → A_CH20_B01_ONE; CH03_C02:ONE → V_CH03_C02_ONE |
| c20-s02-p05 | CH20_B01:ONE → A_CH20_B01_ONE; CH20_S02:ONE → V_CH20_S02_ONE |

## CH20_B01

CH20_B01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: garden densely filled with ordinary coral-pink roses resembling the special rose in petal structure, healthy bushes and foliage, path from RIGHT and a clear grass foreground. No characters, faces on every flower, house or lettering.
  Actual short payload: production/reference-lineage/nodes/A_CH20_B01_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH20_S01

CH20_S01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: prince standing facing LEFT, surprised quiet face, shoulders sinking, empty hands.
  Actual short payload: production/reference-lineage/nodes/V_CH20_S01_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH20_S02

CH20_S02 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: prince lying low on his side/front with face against folded forearms, quietly crying, complete horizontal body and boots; no pillow or injury.
  Actual short payload: production/reference-lineage/nodes/V_CH20_S02_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH20_C01

CH20_C01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: prince walking LEFT, head and torso LEFT, gentle curious expression, complete grounded stride, empty hands.
  Actual short payload: production/reference-lineage/nodes/V_CH20_C01_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.

