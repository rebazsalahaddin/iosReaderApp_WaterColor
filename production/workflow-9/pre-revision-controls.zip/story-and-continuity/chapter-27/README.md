Workflow 7: the agent uses Higgsfield MCP under production/Higgsfield_Agent_Workflow.md and production/Visual_Audit_and_Retry.md. Read production/chapter-27/agent-run-plan.json. Maximum two attempts per canonical reference; no cosmetic regeneration; STOP for manual approval after the complete chapter. Current accepted sources override old planned labels.

# Chapter27 — Look at the Stars

Use [the complete Revision6 plan](Chapter_27_Manual_Reference_and_Pose_Prompts.md). All 15 illustration slots have individual component instructions and numeric placement guides under `page-compositions/`.

Added welcoming friend and tired narrator, sunrise absence and hypothetical laughing approach vignette. Rose fate unresolved, no actual reunion or literal star-bells. All fifteen slots have component rebuild recipes; no legacy empty page may be used as final output.

[Prepared corrections](pose-corrections/POST_GENERATION_CORRECTIONS.md) · [Review record](REVIEW_RECORD.md) · [Book-wide starting point](../../START_HERE.txt)

Legacy finished pages are references only. No new generation has been performed by the agent.
