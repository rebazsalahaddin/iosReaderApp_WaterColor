# Chapter 27 — Location and placement

Generated programmatically before image requests. No image-generation prompt is needed.

[CH27_L01_location_and_placement.png](CH27_L01_location_and_placement.png)

Source images are copied in `reference-images/`. Schematic boxes are proposed placement windows, not measured anatomy or segmentation masks. Existing technical references retain their scope; inspect original-sized copies for details.
