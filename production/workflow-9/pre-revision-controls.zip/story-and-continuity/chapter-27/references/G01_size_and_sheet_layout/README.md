# Chapter 27 — Size and sheet layout

Generated programmatically before image requests. No image-generation prompt is needed.

[CH27_G01_size_and_sheet_layout.png](CH27_G01_size_and_sheet_layout.png)

Source images are copied in `reference-images/`. Schematic boxes are proposed placement windows, not measured anatomy or segmentation masks. Existing technical references retain their scope; inspect original-sized copies for details.
