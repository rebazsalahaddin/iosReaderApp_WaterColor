WORKFLOW 8 EXECUTION: Follow production/Higgsfield_Agent_Workflow.md and production/Visual_Audit_and_Retry.md. Audit each reference before extraction, recheck extraction at final scale, and double-check measured contacts/alignments. At most two attempts per reference and one consolidated page correction round; local composition fixes use no credits. Save individual reading-size/native-size evidence. Deliver the full chapter, clean verified obsolete files, then STOP for manual approval.

# c27-s01-p02 — page assembly

**Status:** planned component rebuild; not generated. Canvas2400×1792 RGB PNG. Output `c27-s01-p02.png`.

**Story:** Six years have passed. I have never told this story before. My friends were glad to see me alive. I was sad, but I told them I was tired.

**Selected moment / continuity:** Memory of welcome home: friend pleased, pilot tired and sad. Not a new present-time arrival.

**Coordinate authority:** authored numeric production targets; ungenerated assets require measured fit verification.

[Placement guide](<PLACEMENT_GUIDE.png>) · [Machine-readable exact targets](<layout.json>)

Origin is top-left. Boxes are `[left, top, width, height]` in final pixels. Align by the named anchor. Uniform scale only; no crop/stretch/mirror of a subject. Head/standing-equivalent locks override a naive silhouette fit. If a source cannot satisfy both locks and its envelope, use its prepared correction request; never distort it.

| Order | Component and selected state | Box (pixels) | Anchor / story realm |
| --- | --- | --- | --- |
| 0 | [CH04_B03:ONE](<../../../chapter-04/references/B03_narrator_room_standing_empty_plate/PROMPT.md>) | [200, 149, 2000, 1493] | center / actual |
| 21 | [CH27_C02:ONE](<../../pose-corrections/C02_pilot_tired_on_returning_home/PROMPT.md>) | [425, 410, 550, 1120] | bottom_center / actual |
| 22 | [CH27_C01:ONE](<../../pose-corrections/C01_grownup_welcoming_narrator_home/PROMPT.md>) | [1460, 450, 500, 1080] | bottom_center / actual |

## 1. CH04_B03:ONE

ONE: same familiar room at the approved standing-WIDE camera, matching window, floor, table/chairs and shelf positions; no people, visitors, held card, drawings or extra furniture. Preserve the entire approved camera field; remove only occupants and their personal props. Existing furniture remains and standing pose sheets contain none.

New 2K plate fits a 2000×1493 region on matched warm paper; preserve full field and deckled edges, never enlarge or crop.

## 2. CH27_C02:ONE

ONE: adult pilot in familiar room standing camera, body and feet RIGHT, head RIGHT toward friend, tired quiet eyes and restrained closed mouth, hands lowered; no broad happy smile. Memory of return six years earlier; full adult-to-room scale lock applies. Sadness is not illness or injury.

Adult standing equivalent H=1000px (room1120px); cross-legged height630px is same adult, not child-sized. Body/head directions come from the exact selected state.

Scale lock: {"adult_standing_equivalent_px": 1120, "adult_head_height_target_px": 246, "prince_standing_equivalent_px": null, "method": "Use this character’s specific scale guide and reference landmarks to determine ONE uniform scale; envelope is an upper bound. Never substitute pilot proportions for a different adult. For a contact group verify internal ratio before placement. If scale and bounds conflict, correct complete source/layout, never shrink only a head or child."}.

## 3. CH27_C01:ONE

ONE: older bespectacled grown-up standing RIGHT side, body and feet LEFT, head LEFT toward returned pilot, small relieved warm smile and open welcoming hand. Different from reserved listener: friends are glad he is alive. No embrace or new kinship asserted.



Scale lock: {"adult_standing_equivalent_px": 1080, "adult_head_height_target_px": 238, "prince_standing_equivalent_px": null, "method": "Use this character’s specific scale guide and reference landmarks to determine ONE uniform scale; envelope is an upper bound. Never substitute pilot proportions for a different adult. For a contact group verify internal ratio before placement. If scale and bounds conflict, correct complete source/layout, never shrink only a head or child."}.

## Assembly procedure

1. Confirm all named states and dependencies exist and pass source review. Existing finished pages are comparison references only.
2. Record raw hashes, dimensions and crop bounds. Preserve native alpha and the attached generated shadow of new sources; use the retained Chapter 1 keying recipe only for accepted legacy keyed sources. Inspect pale interiors, chair gaps and edges. Keep connected hands/props/people together.
3. Place background on2400×1792 warm paper. Existing2400 plates fit exactly. New2K plates use the2000×1493 field with matched paper extension; never enlarge or hide missing pixels by cropping.
4. Measure reference head heights or internal prop landmarks and calculate one uniform scale per group. Apply the target anchor, check floor/seat/support contacts, then save measured x/y/scale.
5. Keep each neutral master's existing soft contact shadow with its complete group, unchanged in shape, position, hue, alpha, softness and intensity. Do not add a second shadow. Only accepted legacy keyed sources use their retained measured grounding recipe. Editorial/memory/paper artwork has no physical floor shadow.
6. Where marks belong on paper, measure the accepted four-corner inner surface and preserve fingers. Reuse canonical marks through the registered paper-plane transform. Do not paste a white rectangle, repaint graphite or invent a different drawing.
7. Composite in listed order. Glass refraction and all continuous contact groups remain opaque internally. Check no duplicated person, furniture, rose, well, rope, bucket or snake.
8. Inspect full-page emotion and reading size, then native-size edges, hands, thin outlines and paper corners. Export a new candidate, never overwrite approved sources. Save layers, as-built layout, source hashes and checks.

## Prewritten correction route

Open [this chapter’s correction guide](<../../pose-corrections/POST_GENERATION_CORRECTIONS.md>). Direction, expression, contact, prop-state and resolution failures already have instructions. First try the other listed compatible complete state if it satisfies this page; otherwise use the prepared request-specific correction. Never improvise a head swap, mirror, upscaling or whole-page generation. Known required variants are already in the initial generation list.

## Narrative staging review — 2026-11-07

Solitary narration and empty desert are intentional. Stars are the gaze target. Memories and the possible return remain visibly conditional; do not manufacture a reunion or resolve the rose’s fate.

Before composition, complete the actor/action/recipient/target and direction record in `layout.json` → `narrative_staging`. After composition, inspect the scene without its caption at reading size, then inspect contacts and edges at native size. Record both results. This planning review is not visual approval.

[Full staging review and required checks](<../../../../production/full-book-rebuild-r6/narrative-staging-audit-v001/REVIEW.txt>)

## Measured continuity and border gate

Read production/Geometry_and_Frame_Continuity.md. Camera group: narrator_wide-7120a59d42. Reuse its measured physical-scale baseline, not a previous source-sheet resize percentage. Check comparable landmarks within 1.5% and unchanged support anchors within 3px; explain actual pose/depth changes. Match the chapter painted field/border, including this opening when applicable. Size any thought image for readability first, then fit the empty frame. Record numerical evidence and compare adjacent pages at equal display zoom.


## Text-to-picture decision (current)

Memory of welcome home: friend pleased, pilot tired and sad. Not a new present-time arrival.

Thought decision: **no_cloud**. The selected physical action, expression, in-world artwork or separately staged editorial/memory scene carries this beat; a cloud would repeat it or invent an unsupported mental picture.
Read production/Text_to_Illustration_Alignment.md and this layout’s text_alignment. This section supersedes any earlier “dialogue only” restriction for the explicitly named thought. Never place its content as a physical prop.

THOUGHT AESTHETICS: Read production/Text_to_Illustration_Alignment.md. If selected, reserve quiet space and verify the inset remains subordinate to the action at reading size; match simplified source rendering and fit a minimal frame. A no-cloud decision stays no-cloud.


## CONTINUITY AND PERFORMANCE FINAL GATE

Read `production/Composition_Continuity_and_Performance.md` and this layout's `composition_performance_contract`. Before placement record actual source landmark endpoints and hashes, two comparable anatomical/prop measurements, shared depth, fixed supports and camera transform. Target boxes reserve space; they do not determine physical scale. Reject internally inconsistent contact groups before fitting. Verify the existing generated shadow touches each actual bearing edge after transforming the complete group; preserve its alpha and avoid a second shadow. Name each actor's expression and gaze recipient. Compare the adjacent page at the same camera-normalized scale and prove a meaningful story difference. Use THREE visible small painted puffs on selected thought pages only. A new camera changes the whole scene; do not selectively enlarge an actor. Save measurements, native/reading-size evidence and duplicate checks, then stop after this chapter for approval.

## Reference lineage — workflow 8
Future generation only: use the node mapping in layout.json. Reuse suitable accepted art. Identity turnaround → approved neutral posture/contact group → one-reference expression edits. Keep generated master shadows attached and unchanged; no added programmatic shadow by default. Inspect source alpha and measured registration before composition. Existing current images stay unchanged during prompt preparation.
