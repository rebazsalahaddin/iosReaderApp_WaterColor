# Chapter 27 — reference generation and posture lineage

Future execution only. Read production/Reference_Lineage_Workflow.md. GPT Image 2.6 Flare, quality medium, 2K, 4:3, one PNG. First accept turnaround, then neutral posture with soft attached shadow, then each expression from that one neutral image. No previous-expression chaining or reference bundles. Existing deliveries are unchanged.

| Page | Source states and lineage nodes |
| --- | --- |
| c27-s01-p01 |  |
| c27-s01-p02 | CH04_B03:ONE → A_CH04_B03_ONE; CH27_C02:ONE → V_CH27_C02_ONE; CH27_C01:ONE → V_CH27_C01_ONE |
| c27-s01-p03 | CH02_B01:ONE → A_CH02_B01_ONE |
| c27-s01-p04 | CH27_B01:ONE → A_CH27_B01_ONE; CH27_S01:L → V_CH27_S01_L |
| c27-s02-p01 | CH25_R01:ONE → A_CH25_R01_ONE |
| c27-s02-p02 | CH27_B01:ONE → A_CH27_B01_ONE; CH27_S01:R → V_CH27_S01_R |
| c27-s02-p03 | CH27_B01:ONE → A_CH27_B01_ONE; CH27_S01:L → V_CH27_S01_L |
| c27-s02-p04 | CH27_B01:ONE → A_CH27_B01_ONE; CH27_S01:R → V_CH27_S01_R |
| c27-s02-p05 | CH27_B01:ONE → A_CH27_B01_ONE; CH27_S01:R → V_CH27_S01_R |
| c27-s03-p01 |  |
| c27-s03-p02 |  |
| c27-s04-p01 |  |
| c27-s04-p02 |  |
| c27-s04-p03 | CH27_C03:ONE → V_CH27_C03_ONE |
| c27-s04-p04 |  |

## CH27_S01

CH27_S01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: full adult pilot standing by window position, eyes lifted quietly toward stars, soft bittersweet smile.
  Actual short payload: production/reference-lineage/nodes/V_CH27_S01_L/PROMPT.txt
- R: same adult looking toward the sky with restrained worry and wet eyes, not sobbing theatrically.
  Actual short payload: production/reference-lineage/nodes/V_CH27_S01_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH27_B01

CH27_B01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: familiar room at the approved standing-WIDE camera at night, open window showing small distant stars, existing furniture/window/floor unchanged, no people, cards, drawings or new props.
  Actual short payload: production/reference-lineage/nodes/A_CH27_B01_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH27_C01

CH27_C01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: older bespectacled grown-up standing RIGHT side, body and feet LEFT, head LEFT toward returned pilot, small relieved warm smile and open welcoming hand.
  Actual short payload: production/reference-lineage/nodes/V_CH27_C01_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH27_C02

CH27_C02 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: adult pilot in familiar room standing camera, body and feet RIGHT, head RIGHT toward friend, tired quiet eyes and restrained closed mouth, hands lowered; no broad happy smile.
  Actual short payload: production/reference-lineage/nodes/V_CH27_C02_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH27_C03

CH27_C03 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: familiar prince taking one gentle grounded step LEFT, gold hair, coral scarf, warm small laugh, empty hands; complete body.
  Actual short payload: production/reference-lineage/nodes/V_CH27_C03_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.

