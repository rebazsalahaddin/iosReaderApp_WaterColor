# Chapter 18 — reference generation and posture lineage

Future execution only. Read production/Reference_Lineage_Workflow.md. GPT Image 2.6 Flare, quality medium, 2K, 4:3, one PNG. First accept turnaround, then neutral posture with soft attached shadow, then each expression from that one neutral image. No previous-expression chaining or reference bundles. Existing deliveries are unchanged.

| Page | Source states and lineage nodes |
| --- | --- |
| c18-s01-p01 | CH02_B00:ONE → A_CH02_B00_ONE; CH18_R01:L → V_CH18_R01_L |
| c18-s01-p02 | CH02_S02:L → V_CH02_S02_L; CH18_R01:L → V_CH18_R01_L |
| c18-s01-p03 | CH02_S02:L → V_CH02_S02_L; CH18_R01:L → V_CH18_R01_L |
| c18-s01-p04 | CH02_S02:L → V_CH02_S02_L; CH18_R01:L → V_CH18_R01_L |
| c18-s01-p05 | CH02_S05:L → V_CH02_S05_L; CH18_R01:R → V_CH18_R01_R |
| c18-s01-p06 | CH03_S03:R → V_CH03_S03_R; CH18_R01:L → V_CH18_R01_L |

## CH18_R01

CH18_R01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: one small cream flower with exactly THREE clearly separated petals, one slender green stem and simple leaves, upright on a tiny dry soil patch.
  Actual short payload: production/reference-lineage/nodes/V_CH18_R01_L/PROMPT.txt
- R: same three-petalled flower leaning slightly in a gentle breeze, still rooted and healthy.
  Actual short payload: production/reference-lineage/nodes/V_CH18_R01_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.

