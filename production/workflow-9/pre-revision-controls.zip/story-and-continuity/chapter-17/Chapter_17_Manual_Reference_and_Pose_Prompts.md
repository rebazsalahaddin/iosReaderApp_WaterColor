# Chapter 17 — reference generation and posture lineage

Future execution only. Read production/Reference_Lineage_Workflow.md. GPT Image 2.6 Flare, quality medium, 2K, 4:3, one PNG. First accept turnaround, then neutral posture with soft attached shadow, then each expression from that one neutral image. No previous-expression chaining or reference bundles. Existing deliveries are unchanged.

| Page | Source states and lineage nodes |
| --- | --- |
| c17-s01-p01 | CH02_B00:ONE → A_CH02_B00_ONE; CH16_R01:ONE → A_CH16_R01_ONE |
| c17-s01-p02 | CH16_R01:ONE → A_CH16_R01_ONE; CH16_R02:R → A_CH16_R02_R |
| c17-s01-p03 | CH16_R01:ONE → A_CH16_R01_ONE; CH16_R02:R → A_CH16_R02_R |
| c17-s01-p04 | CH16_R01:ONE → A_CH16_R01_ONE; CH16_R02:R → A_CH16_R02_R |
| c17-s02-p01 | CH17_S01:L → V_CH17_S01_L; CH17_S03:L → V_CH17_S03_L |
| c17-s02-p02 | CH17_S01:L → V_CH17_S01_L; CH17_S03:L → V_CH17_S03_L |
| c17-s02-p03 | CH17_S01:R → V_CH17_S01_R; CH17_S03:L → V_CH17_S03_L |
| c17-s02-p04 | CH17_C01:ONE → V_CH17_C01_ONE; CH17_S03:L → V_CH17_S03_L |
| c17-s02-p05 | CH17_C01:ONE → V_CH17_C01_ONE; CH17_S03:L → V_CH17_S03_L |
| c17-s02-p06 | CH17_C01:ONE → V_CH17_C01_ONE; CH17_S03:L → V_CH17_S03_L |
| c17-s03-p01 | CH17_S01:L → V_CH17_S01_L; CH17_S03:R → V_CH17_S03_R |
| c17-s03-p02 | CH17_S01:L → V_CH17_S01_L; CH17_S03:R → V_CH17_S03_R |
| c17-s03-p03 | CH17_S02:ONE → V_CH17_S02_ONE |
| c17-s03-p04 | CH17_S02:ONE → V_CH17_S02_ONE |
| c17-s03-p05 | CH17_S02:ONE → V_CH17_S02_ONE |
| c17-s03-p06 | CH17_S02:ONE → V_CH17_S02_ONE |

## CH17_A01

CH17_A01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: one slender gold-yellow desert snake in a loose low ring, closed small mouth, simple dark eyes, quiet non-menacing expression.
  Actual short payload: production/reference-lineage/nodes/V_CH17_A01_L/PROMPT.txt
- R: same snake in an extended gentle S curve at the same body thickness and total length.
  Actual short payload: production/reference-lineage/nodes/V_CH17_A01_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH17_S01

CH17_S01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: prince standing facing LEFT, curious calm expression, one small questioning hand.
  Actual short payload: production/reference-lineage/nodes/V_CH17_S01_L/PROMPT.txt
- R: same prince gazing upward thoughtfully toward a star, hands relaxed, quiet sadness.
  Actual short payload: production/reference-lineage/nodes/V_CH17_S01_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH17_S02

CH17_S02 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: prince standing still, looking down at one thin gold snake loosely encircling ONE ankle like a bracelet; complete child and complete single snake with continuous anatomy.
  Actual short payload: production/reference-lineage/nodes/V_CH17_S02_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH17_S03

CH17_S03 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: accepted thin gold-yellow snake in one loose low ring, head gently raised, quiet closed mouth.
  Actual short payload: production/reference-lineage/nodes/V_CH17_S03_L/PROMPT.txt
- R: same snake extended in one gentle S curve, same body length/thickness, head toward RIGHT.
  Actual short payload: production/reference-lineage/nodes/V_CH17_S03_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH17_C01

CH17_C01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: prince standing on RIGHT, torso/feet LEFT, head slightly down-left toward snake, hands lowered, quiet lonely serious mouth; no smile or physical contact.
  Actual short payload: production/reference-lineage/nodes/V_CH17_C01_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.

