WORKFLOW 8 EXECUTION: Follow production/Higgsfield_Agent_Workflow.md and production/Visual_Audit_and_Retry.md. Audit each reference before extraction, recheck extraction at final scale, and double-check measured contacts/alignments. At most two attempts per reference and one consolidated page correction round; local composition fixes use no credits. Save individual reading-size/native-size evidence. Deliver the full chapter, clean verified obsolete files, then STOP for manual approval.

# c16-s02-p02 — page assembly

**Status:** planned component rebuild; not generated. Canvas2400×1792 RGB PNG. Output `c16-s02-p02.png`.

**Story:** First, New Zealand and Australia. Their lamplighters lit the lamps, then went to sleep. Next, China and Siberia entered the dance.

**Selected moment / continuity:** Separate successive regional vignettes: Australasia resting, China/Siberia working. App text identifies regions; no invented costumes.

**Coordinate authority:** authored numeric production targets; ungenerated assets require measured fit verification.

[Placement guide](<PLACEMENT_GUIDE.png>) · [Machine-readable exact targets](<layout.json>)

Origin is top-left. Boxes are `[left, top, width, height]` in final pixels. Align by the named anchor. Uniform scale only; no crop/stretch/mirror of a subject. Head/standing-equivalent locks override a naive silhouette fit. If a source cannot satisfy both locks and its envelope, use its prepared correction request; never distort it.

| Order | Component and selected state | Box (pixels) | Anchor / story realm |
| --- | --- | --- | --- |
| 15 | [CH14_R01:L](<../../../chapter-14/references/R01_streetlamp_on_and_off/PROMPT.md>) | [890, 480, 220, 870] | bottom_center / editorial_region_1 |
| 15 | [CH14_R01:L](<../../../chapter-14/references/R01_streetlamp_on_and_off/PROMPT.md>) | [1820, 480, 220, 870] | bottom_center / editorial_region_2 |
| 20 | [CH16_S01:R](<../../reusable-poses/S01_earth_lamplighters_working_and_resting/PROMPT.md>) | [390, 650, 460, 700] | bottom_center / editorial_region_1 |
| 20 | [CH16_S01:L](<../../reusable-poses/S01_earth_lamplighters_working_and_resting/PROMPT.md>) | [1320, 600, 460, 750] | bottom_center / editorial_region_2 |

## 1. CH14_R01:L

LEFT: one complete streetlamp in ON state, one small warm flame inside lantern, restrained internal light. No broad halo on key background. Glass retains illustrated local highlights, not a magenta interior; inspect at intended background. No lighting pole attached.



## 2. CH14_R01:L

LEFT: one complete streetlamp in ON state, one small warm flame inside lantern, restrained internal light. No broad halo on key background. Glass retains illustrated local highlights, not a magenta interior; inspect at intended background. No lighting pole attached.



## 3. CH16_S01:R

RIGHT: one anonymous adult lamplighter resting seated on a simple stool, pole set beside him, full coherent group. Use reference for profession/equipment, not a claim that the fifth-world man lives on Earth. Avoid ethnic caricature and invented national costume; reuse small figures in separate editorial vignettes. DIRECTION LOCK: LEFT worker body/head RIGHT toward lamp to right; RIGHT worker seated body RIGHT, resting head slightly down. Full stool included.



Scale lock: {"adult_standing_equivalent_px": 1000, "adult_head_height_target_px": null, "prince_standing_equivalent_px": null, "method": "Use this character’s specific scale guide and reference landmarks to determine ONE uniform scale; envelope is an upper bound. Never substitute pilot proportions for a different adult. For a contact group verify internal ratio before placement. If scale and bounds conflict, correct complete source/layout, never shrink only a head or child.", "head_proportion_authority": "Preserve the specific adult identity/technical guide; no generic pilot head fraction."}.

## 4. CH16_S01:L

LEFT: one anonymous adult street lamplighter in simple neutral period work clothes, holding an unlit lighting pole after lighting, full body. Use reference for profession/equipment, not a claim that the fifth-world man lives on Earth. Avoid ethnic caricature and invented national costume; reuse small figures in separate editorial vignettes. DIRECTION LOCK: LEFT worker body/head RIGHT toward lamp to right; RIGHT worker seated body RIGHT, resting head slightly down. Full stool included.



Scale lock: {"adult_standing_equivalent_px": 750, "adult_head_height_target_px": null, "prince_standing_equivalent_px": null, "method": "Use this character’s specific scale guide and reference landmarks to determine ONE uniform scale; envelope is an upper bound. Never substitute pilot proportions for a different adult. For a contact group verify internal ratio before placement. If scale and bounds conflict, correct complete source/layout, never shrink only a head or child.", "head_proportion_authority": "Preserve the specific adult identity/technical guide; no generic pilot head fraction."}.

## Assembly procedure

1. Confirm all named states and dependencies exist and pass source review. Existing finished pages are comparison references only.
2. Record raw hashes, dimensions and crop bounds. Preserve native alpha and the attached generated shadow of new sources; use the retained Chapter 1 keying recipe only for accepted legacy keyed sources. Inspect pale interiors, chair gaps and edges. Keep connected hands/props/people together.
3. Place background on2400×1792 warm paper. Existing2400 plates fit exactly. New2K plates use the2000×1493 field with matched paper extension; never enlarge or hide missing pixels by cropping.
4. Measure reference head heights or internal prop landmarks and calculate one uniform scale per group. Apply the target anchor, check floor/seat/support contacts, then save measured x/y/scale.
5. Keep each neutral master's existing soft contact shadow with its complete group, unchanged in shape, position, hue, alpha, softness and intensity. Do not add a second shadow. Only accepted legacy keyed sources use their retained measured grounding recipe. Editorial/memory/paper artwork has no physical floor shadow.
6. Where marks belong on paper, measure the accepted four-corner inner surface and preserve fingers. Reuse canonical marks through the registered paper-plane transform. Do not paste a white rectangle, repaint graphite or invent a different drawing.
7. Composite in listed order. Glass refraction and all continuous contact groups remain opaque internally. Check no duplicated person, furniture, rose, well, rope, bucket or snake.
8. Inspect full-page emotion and reading size, then native-size edges, hands, thin outlines and paper corners. Export a new candidate, never overwrite approved sources. Save layers, as-built layout, source hashes and checks.

## Prewritten correction route

Open [this chapter’s correction guide](<../../pose-corrections/POST_GENERATION_CORRECTIONS.md>). Direction, expression, contact, prop-state and resolution failures already have instructions. First try the other listed compatible complete state if it satisfies this page; otherwise use the prepared request-specific correction. Never improvise a head swap, mirror, upscaling or whole-page generation. Known required variants are already in the initial generation list.

## Narrative staging review — 2026-11-07

Category portraits and geographic lighting diagrams are editorial. Select the named separate portrait crop from the shared sheet; do not repeat the whole sheet or invent a physical crowd meeting.

Before composition, complete the actor/action/recipient/target and direction record in `layout.json` → `narrative_staging`. After composition, inspect the scene without its caption at reading size, then inspect contacts and edges at native size. Record both results. This planning review is not visual approval.

[Full staging review and required checks](<../../../../production/full-book-rebuild-r6/narrative-staging-audit-v001/REVIEW.txt>)

## Measured continuity and border gate

Read production/Geometry_and_Frame_Continuity.md. Camera group: c16-s02-p02-editorial-camera. Reuse its measured physical-scale baseline, not a previous source-sheet resize percentage. Check comparable landmarks within 1.5% and unchanged support anchors within 3px; explain actual pose/depth changes. Match the chapter painted field/border, including this opening when applicable. Size any thought image for readability first, then fit the empty frame. Record numerical evidence and compare adjacent pages at equal display zoom.


## Text-to-picture decision (current)

Separate successive regional vignettes: Australasia resting, China/Siberia working. App text identifies regions; no invented costumes.

Thought decision: **no_cloud**. The selected physical action, expression, in-world artwork or separately staged editorial/memory scene carries this beat; a cloud would repeat it or invent an unsupported mental picture.
Read production/Text_to_Illustration_Alignment.md and this layout’s text_alignment. This section supersedes any earlier “dialogue only” restriction for the explicitly named thought. Never place its content as a physical prop.

THOUGHT AESTHETICS: Read production/Text_to_Illustration_Alignment.md. If selected, reserve quiet space and verify the inset remains subordinate to the action at reading size; match simplified source rendering and fit a minimal frame. A no-cloud decision stays no-cloud.


## CONTINUITY AND PERFORMANCE FINAL GATE

Read `production/Composition_Continuity_and_Performance.md` and this layout's `composition_performance_contract`. Before placement record actual source landmark endpoints and hashes, two comparable anatomical/prop measurements, shared depth, fixed supports and camera transform. Target boxes reserve space; they do not determine physical scale. Reject internally inconsistent contact groups before fitting. Verify the existing generated shadow touches each actual bearing edge after transforming the complete group; preserve its alpha and avoid a second shadow. Name each actor's expression and gaze recipient. Compare the adjacent page at the same camera-normalized scale and prove a meaningful story difference. Use THREE visible small painted puffs on selected thought pages only. A new camera changes the whole scene; do not selectively enlarge an actor. Save measurements, native/reading-size evidence and duplicate checks, then stop after this chapter for approval.

## Reference lineage — workflow 8
Future generation only: use the node mapping in layout.json. Reuse suitable accepted art. Identity turnaround → approved neutral posture/contact group → one-reference expression edits. Keep generated master shadows attached and unchanged; no added programmatic shadow by default. Inspect source alpha and measured registration before composition. Existing current images stay unchanged during prompt preparation.
