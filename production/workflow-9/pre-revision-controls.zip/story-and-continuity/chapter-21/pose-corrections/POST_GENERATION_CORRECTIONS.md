# Chapter 21 — planned states and material corrections

Known expression/contact/prop changes are included in the lineage catalog before execution. Read production/Reference_Lineage_Workflow.md and production/Visual_Correction_Guide.txt. A C-code identifies an authored state; it is not a fresh retry budget.

Audit turnaround, neutral posture and then each single-reference expression. Keep dot eyes, face/hair/clothes/size/furniture/camera/support and generated soft shadow unchanged outside the named action. New outputs use true alpha; legacy keyed originals retain their preparation history. Use the page's exact source text and geometry contract.

A first-pass material source failure requires precise coordinates, observed/expected, all issue IDs, local-fix analysis and exact correction. Prepare ONE reviewed local correction board with dominant intact neutral and diagnostic crops/positive targets for every issue. Upload that board alone for the variant retry with the complete original short prompt plus fixes. Preserve failed bytes locally and all passing features. No paid guide or cosmetic retry. After two attempts including historical sheet jobs, block the unresolved state; never rename it or regenerate under a neutral label.

Check every page and the ordered sequence for visible expression, interaction, relative scale, attached shadows, unique text beat and selected thoughts. Local placement/alpha repairs use no generation attempt. One consolidated source-correction round per page. Complete only this authorized chapter and stop for manual approval.
## Narrative staging supplement

Fox/prince eyelines and distance evolve from meeting through taming to farewell. The prince addresses the real roses in the garden; do not move the fox into that garden or literalise the invisible bond.

Read every page's narrative_staging, text_alignment and reference_lineage contracts before choosing a source. Name the actor, action, recipient or justified omission, gaze, occupied hands and exact visible instant. Preserve the specific exceptions in the page recipe and inspect both reading-size meaning and native contacts. A correction still uses its original canonical attempt allowance and the same neutral authority; this supplement is planning, not visual approval.
