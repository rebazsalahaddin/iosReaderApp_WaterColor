# Chapter 21 — reference generation and posture lineage

Future execution only. Read production/Reference_Lineage_Workflow.md. GPT Image 2.6 Flare, quality medium, 2K, 4:3, one PNG. First accept turnaround, then neutral posture with soft attached shadow, then each expression from that one neutral image. No previous-expression chaining or reference bundles. Existing deliveries are unchanged.

| Page | Source states and lineage nodes |
| --- | --- |
| c21-s01-p01 | CH21_B01:ONE → A_CH21_B01_ONE |
| c21-s01-p02 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:L → V_CH21_S01_L; CH03_S03:L → V_CH03_S03_L |
| c21-s01-p03 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:L → V_CH21_S01_L; CH03_S03:L → V_CH03_S03_L |
| c21-s01-p04 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s01-p05 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s01-p06 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s02-p01 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s02-p02 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s02-p03 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L; CH07_R02:R → V_CH07_R02_R |
| c21-s02-p04 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s02-p05 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s02-p06 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s02-p07 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S05:L → V_CH02_S05_L |
| c21-s02-p08 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S05:L → V_CH02_S05_L |
| c21-s03-p01 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s03-p02 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH02_S02:L → V_CH02_S02_L |
| c21-s03-p03 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:L → V_CH21_S02_L |
| c21-s03-p04 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:L → V_CH21_S02_L |
| c21-s03-p05 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S03:L → V_CH21_S03_L; CH21_S02:L → V_CH21_S02_L |
| c21-s03-p06 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:R → V_CH21_S02_R |
| c21-s03-p07 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:R → V_CH21_S02_R |
| c21-s03-p08 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:R → V_CH21_S02_R |
| c21-s04-p01 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S03:R → V_CH21_S03_R; CH21_S02:L → V_CH21_S02_L |
| c21-s04-p02 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S03:R → V_CH21_S03_R; CH21_S02:L → V_CH21_S02_L |
| c21-s04-p03 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S03:R → V_CH21_S03_R; CH21_S02:L → V_CH21_S02_L |
| c21-s04-p04 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH03_S03:R → V_CH03_S03_R |
| c21-s05-p01 | CH20_B01:ONE → A_CH20_B01_ONE; CH02_S02:L → V_CH02_S02_L |
| c21-s05-p02 | CH20_B01:ONE → A_CH20_B01_ONE; CH02_S02:L → V_CH02_S02_L |
| c21-s05-p03 | CH20_B01:ONE → A_CH20_B01_ONE; CH02_S02:L → V_CH02_S02_L |
| c21-s05-p04 | CH20_B01:ONE → A_CH20_B01_ONE; CH02_S02:L → V_CH02_S02_L |
| c21-s05-p05 | CH20_B01:ONE → A_CH20_B01_ONE; CH02_S02:L → V_CH02_S02_L |
| c21-s06-p01 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:L → V_CH21_S02_L |
| c21-s06-p02 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:L → V_CH21_S02_L |
| c21-s06-p03 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:L → V_CH21_S02_L |
| c21-s06-p04 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:L → V_CH21_S02_L |
| c21-s06-p05 | CH21_B01:ONE → A_CH21_B01_ONE; CH21_S01:R → V_CH21_S01_R; CH21_S02:L → V_CH21_S02_L |

## CH21_B01

CH21_B01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- ONE: quiet grassy meadow with one apple tree on LEFT, open sitting space in foreground, a band of golden wheat farther back on RIGHT. Gentle daylight, no animals, people, firearms, buildings or words.
  Actual short payload: production/reference-lineage/nodes/A_CH21_B01_ONE/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH21_S01

CH21_S01 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: same fox standing low on four paws, head turned RIGHT, gently cautious, tail relaxed.
  Actual short payload: production/reference-lineage/nodes/V_CH21_S01_L/PROMPT.txt
- R: fox sitting neatly, head turned RIGHT in quiet attention, tail curled beside hind paws, mouth closed.
  Actual short payload: production/reference-lineage/nodes/V_CH21_S01_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH21_S02

CH21_S02 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: prince sitting in grass-level footing facing LEFT, legs folded comfortably, hands resting on knees, patient closed-mouth attention.
  Actual short payload: production/reference-lineage/nodes/V_CH21_S02_L/PROMPT.txt
- R: same seated child facing LEFT, one small open-hand gesture as he asks a question, thoughtful face.
  Actual short payload: production/reference-lineage/nodes/V_CH21_S02_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.


## CH21_S03

CH21_S03 — WORKFLOW 8 AGENT ROUTING CARD (not an image-model payload)
MODEL: GPT Image 2.6 Flare / gpt_image_2_6_flare; quality medium; 2K; 4:3; PNG; batch_size 1. Native transparent isolated references; opaque background plates.
REFERENCE: Read production/Reference_Lineage_Workflow.md and production/reference-lineage/catalog.json. Inspect/reuse the identity turnaround, approve the neutral posture/contact master, then edit each expression from exactly ONE approved neutral image. Never submit this routing card or the old numbered bundle to the model.
DIRECTION AND STATE:
- L: same fox standing with a small eager lift of head and one front paw slightly raised, happy anticipation, no human jumping pose.
  Actual short payload: production/reference-lineage/nodes/V_CH21_S03_L/PROMPT.txt
- R: fox seated facing RIGHT with restrained wet eyes, quiet sad affection, unchanged anatomy.
  Actual short payload: production/reference-lineage/nodes/V_CH21_S03_R/PROMPT.txt
L/R identify legacy logical states, not output columns. Generate a single state only when needed. All variants return to the same neutral master, never to a sibling expression. Preserve face, dot eyes, hair, clothes, age, anatomy, dimensions, camera, furniture and registration outside named edits. Preserve the generated attached shadow including alpha; no extra shadow by default.
AUDIT: Compare all offline identity/scale/story evidence; audit native alpha, emotion, exact contact and parent-shadow preservation. Read story-context.json and audit-contract.json. Old attachments stay for audit only. Accepted current artwork remains reusable and untouched.
MEASURED CONTINUITY AND FRAMING LOCK: Use measured anatomy and support anchors from page layout.json; same camera keeps size/location. Final 2400×1792 geometry remains unchanged; check actual 2K source pixels.
COMPOSITION CONTINUITY AND PERFORMANCE LOCK: One physical contact group, correct relative ratios, attached single-owner shadow, clear expression/gaze/recipient and meaningful unique page beat.
TEXT-TO-ILLUSTRATION ALIGNMENT: Exact page story-context remains authoritative; no early reveal or invented contact. Thought contents are separate assets.
THOUGHT AESTHETICS AND SCENE HIERARCHY: Selected thoughts only, readable quiet watercolor contents, adapted frame and three owner-linked puffs; do not crowd the page.
BUDGET: Two attempts maximum per canonical state including historical sheet attempts. Reuse before spending. For a material retry use one locally prepared reviewed board with intact neutral authority and every issue; keep full original short prompt plus precise fixes. No third attempt. Stop after one chapter for manual approval.

