# Illustration production — workflow 8

This directory is the independent project root. Read START_HERE.txt, production/MASTER_PROMPT.txt, production/Reference_Lineage_Workflow.md, production/Execution_Instructions.md and production/agent-policy.json. All paths stay root-relative inside this project.

The active model is GPT Image 2.6 Flare, quality medium, 2K, 4:3, batch_size 1, PNG; explicit transparent isolated references and opaque background plates. Audit/reuse identity turnaround, then neutral posture/contact master with soft generated shadow, then each expression from exactly one accepted neutral. Never chain expressions or upload a large reference bundle. Protect identity/dot eyes/size/clothes/furniture/registration and preserve parent shadow exactly. Full details and all node routes are in the lineage guide/catalog.

The current user request changes prompts only. Do not generate, revise, re-export or delete illustrations/reference media, deliveries, animation/audio or historical job/audit records in this maintenance pass. No paid jobs. Preparation is not execution or approval.

On later explicit execution use chapter lineage_execution_order, both ledgers and lineage_guard.py. Maximum two attempts globally per canonical state including old sheet jobs. Unknown submissions block resubmission. Graphical retry uses one reviewed board with intact authority and every material issue; no paid guide generation. Never evade spent attempts by renaming a source or foundation.

Every page needs exact text/chronology, identity, measured relative scale, stable same-camera anchors, clear expressions/recipient, complete contacts, readable selected thoughts with three puffs and unique meaning. Read Geometry_and_Frame_Continuity.md, Composition_Continuity_and_Performance.md and Text_to_Illustration_Alignment.md. Current measured records override provisional plans. Generated alpha/shadows need actual visual inspection, not just format validation.

After an actually completed chapter perform dependency-checked Cleanup_Instructions.md, retain one current delivery/ZIP and required originals/layers/measurements/audits/attempts. This maintenance pass does not authorize deleting existing artwork. Run python3 production/validate_package.py. Deliver exactly one authorized chapter, mark awaiting_chapter_approval and STOP until real manual approval. A planning pass is never a new visual approval.
